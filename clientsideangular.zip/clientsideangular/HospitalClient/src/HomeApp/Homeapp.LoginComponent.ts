import { Component } from '@angular/core';
import { MySecurity } from '../Security/Security.Token';
import { Router } from '@angular/router'
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { DataModel } from './DataModel';

@Component({
  templateUrl: './HomeApp.Login.html',
  
})
export class LoginComponent{
  dmobj:DataModel = new DataModel();
  constructor(public mysecurityobj : MySecurity, private _router: Router,public httpobj: HttpClient){

  }
  Login(){
    const headers = new HttpHeaders({'Content-Type':'application/json; charset=utf-8'});
    var observable = this.httpobj.post("https://localhost:44366/api/Security",JSON.stringify(this.dmobj.username),{headers,responseType:'text'});
    observable.subscribe(res=>this.Success(res),res=>this.Error(res));
  }
  Success(res){
    this.mysecurityobj.token = res;
    alert(res);
    this._router.navigate(['/Master']);
  }
  Error(res){
    alert(res);
  }   
}


