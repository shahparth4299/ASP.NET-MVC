import { Component } from '@angular/core';
@Component({
  templateUrl: './HomeApp.Home.html',
  
})
export class HomeComponent{
  
}


