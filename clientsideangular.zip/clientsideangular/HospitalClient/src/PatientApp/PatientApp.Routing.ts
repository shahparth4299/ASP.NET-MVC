import {PatientAddComponent} from "./PatientApp.PatientAddComponent"
export const PatientRoutes = [
    { path: 'Add', component: PatientAddComponent }
]