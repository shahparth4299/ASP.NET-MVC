export interface Data{
    age: number;
    gender: string;
}