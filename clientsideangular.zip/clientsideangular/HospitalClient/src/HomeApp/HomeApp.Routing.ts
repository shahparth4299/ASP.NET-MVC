import {HomeComponent} from "./Homeapp.HomeComponent"
import { LoginComponent } from './Homeapp.LoginComponent'
import { MasterPageComponent } from './Homeapp.MasterPageComponent'
import  {MyAuthGuard} from '../Security/Security.AuthGuard'
export const HomeRoutes = [
    { path: 'Login', component: LoginComponent },
    { path: '', component: MasterPageComponent, canActive : [MyAuthGuard] },
    { path: 'Master', component: MasterPageComponent, canActive : [MyAuthGuard] },
    { path: 'Home', component: HomeComponent , canActive : [MyAuthGuard]},
    { path: 'Patient', loadChildren: () => import('../PatientApp/PatientApp.PatientModule')
    .then(m=> m.PatientModule), canActive : [MyAuthGuard]}
]