export class Patient{
    name: string = "Parth Shah";
    address: string = "Mumbai";
    Problems: Array<PatientProblem> = new Array<PatientProblem>();
}
export class PatientProblem{
    id:number;
    problem: string = "";
}