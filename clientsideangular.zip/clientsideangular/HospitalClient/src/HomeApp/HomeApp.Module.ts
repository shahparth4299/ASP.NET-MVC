import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { HomeRoutes } from './HomeApp.Routing';
import { RouterModule } from '@angular/router';
import { HomeComponent  } from './Homeapp.HomeComponent';
import { MasterPageComponent} from './Homeapp.MasterPageComponent';
import { MySecurity } from '../Security/Security.Token'
import { IndexComponent } from './HomeApp.IndexComponent'
import { LoginComponent } from './Homeapp.LoginComponent'
import { MyAuthGuard } from '../Security/Security.AuthGuard';

@NgModule({
  declarations: [
    HomeComponent,
    MasterPageComponent,
    LoginComponent,
    IndexComponent
  ],
  imports: [
    BrowserModule, FormsModule, HttpClientModule ,
    RouterModule.forRoot(HomeRoutes)
  ],
  providers: [MySecurity,MyAuthGuard],
  bootstrap: [IndexComponent]
})
export class HomeModule { }
