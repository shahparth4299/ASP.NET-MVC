import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './HomeApp.Master.html',
  
})
export class MasterPageComponent{
  
}


