export class MySecurity{
    token:string = "abc";
}