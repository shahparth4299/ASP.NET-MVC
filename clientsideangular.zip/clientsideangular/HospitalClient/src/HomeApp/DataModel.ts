export class DataModel{
    username:string = "";
}