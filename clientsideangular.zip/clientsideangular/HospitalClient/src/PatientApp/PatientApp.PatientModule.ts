import { CommonModule } from '@angular/common'
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { PatientAddComponent } from './PatientApp.PatientAddComponent';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { PatientRoutes } from './PatientApp.Routing';
import { JwtInterceptor } from '../Security/Security.Interceptor';
@NgModule({
  declarations: [
    PatientAddComponent
  ],
  imports: [
    CommonModule,
    FormsModule, 
    HttpClientModule ,
    RouterModule.forChild(PatientRoutes)
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi:true}
  ],
  bootstrap: [PatientAddComponent]
})
export class PatientModule { }
