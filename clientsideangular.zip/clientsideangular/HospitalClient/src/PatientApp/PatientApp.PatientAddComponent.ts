import { Component } from '@angular/core';
import { Patient, PatientProblem } from "./PatientApp.PatientAddModel";
import { HttpClient } from '@angular/common/http';
import { Subscriber, Observable, merge, pipe, timer, from } from 'rxjs';
import  { map, filter, toArray, debounce} from 'rxjs/operators'
@Component({
  templateUrl: './PatientApp.PatientAdd.html',
  styleUrls: ['./PatientApp.PatientAdd.css']
})
export class PatientAddComponent {
  title = 'HospitalClient';
  patientobj:Patient = new Patient();
  patientobjs:Array<Patient> = new Array<Patient>();
  constructor(public httpobj: HttpClient){

  }
  AddInMemory(){
    this.patientobjs.push(this.patientobj);
    this.patientobj = new Patient();
    
  }
  Add(){
    console.log(this.patientobjs);
    
    const source = from(this.patientobjs);
    const example = source.pipe(filter(patient => patient.address == "Mumbai"));
    const subscribe = example.subscribe(val => console.log(val));
    
    var observable = this.httpobj.post("https://localhost:44366/api/PatientApi",this.patientobjs);
    observable.subscribe(res=>this.Success(res),res=>this.Error(res));
  }
  Success(res){
    this.patientobjs = res;
  }
  Error(res){
    alert("Something went wrong");
  }
}


